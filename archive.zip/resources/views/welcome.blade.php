@extends('layouts.app')

@section('content')
<div class="image">
	<div class="container">
	<br><br><br><br><br><br><br><br><br><br><br><br><br>
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="panel panel-default" style="width:70%; margin:0 auto;">
					<div class="panel-heading" style="text-align:center;">Bienvenue sur K-SOS !</div>

					<div class="panel-body" style="text-align:center;">
						Votre nouveau réseau K-social, jeune et dynamique ! 
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
