<div class="media">
    <a class="pull-left" href="#">
        <img src={{url("/img/profils/{$message->user->id}.png ?s=64")}} height='40px' width="40px"
             alt="{{ $message->user->name }}" class="img-circle">

    </a>
    <div class="media-body">
        <h5 class="media-heading">{{ $message->user->name }}</h5>
        <p>{{ $message->body }}</p>
        <div class="text-muted">
            <small>Posted {{ $message->created_at->diffForHumans() }}</small>
        </div>
    </div>
</div>