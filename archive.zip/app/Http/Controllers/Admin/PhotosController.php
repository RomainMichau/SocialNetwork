<?php

namespace App\Http\Controllers\Admin;

use App\Photo;
use App\Post;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class PhotosController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $voir = array(0 => 'Moi uniquement', 1 => 'Mes amis', 2 => 'Tout le monde');
        return view('admin.photos.create', compact('voir'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'picture'      => 'required|image',
        ]);
        if($validation->fails())
        {
            return redirect()->route('admin.photos.create')->withInput($request->all())->withErrors($validation->errors());
        }
        else
        {
            $photo = new Photo;
            $photo->save();
            $request['picture']->move(public_path(). "/img/photos","{$photo->id}.png");
            $post = new Post;
            $post->user_id = Auth::user()->id;
            $post->event_id = 0;
            $post->video_id = 0;
            $post->photo_id = $photo->id;
            $post->type = 0;
            $post->voir = $request->get('voir');
            $post->save();
            return redirect()->route('about')->with('message', 'New photo!!!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
