<?php

namespace App\Http\Controllers\Admin;

use App\Video;
use App\Post;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class VideosController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $voir = array(0 => 'Moi uniquement', 1 => 'Mes amis', 2 => 'Tout le monde');
        return view('admin.videos.create', compact('voir'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'video'  => 'mimes:mp4,mov,ogg | max:20000'
        ]);
        if($validation->fails())
        {
            return redirect()->route('admin.videos.create')->withInput($request->all())->withErrors($validation->errors());
        }
        else
        {
            $video = new Video;
            $video->save();
            $request['video']->move(public_path(). "/img/videos","{$video->id}.mp4");
            $post = new Post;
            $post->user_id = Auth::user()->id;
            $post->event_id = 0;
            $post->photo_id = 0;
            $post->video_id = $video->id;
            $post->type = 1;
            $post->voir = $request->get('voir');
            $post->save();
            return redirect()->route('about')->with('message', 'New Video!!!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
